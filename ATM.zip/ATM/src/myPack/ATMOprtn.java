package myPack;

public interface ATMOprtn {
public void viewBalance();
public void withdrawAmnt(double withdrawAmount);
public void depositeAmnt(double depositAmount);
public void viewMiniStatement();
}
